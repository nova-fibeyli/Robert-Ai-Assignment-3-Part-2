import pytest
from src.preprocess_and_load import load_data

def test_load_data():
    # Replace 'path/to/file' with a mock or real file path during actual testing
    data = load_data("path/to/file")
    assert data is not None
